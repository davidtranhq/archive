if not socket then error("No socket.") end
